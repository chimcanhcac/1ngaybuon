// *require stuff*
var PluginName = "lottery";    // plugin_scope in plugins.js
var config = JSON.parse(global.privateFileMap[PluginName]["config"].toString())["config"];
var plugininfo = JSON.parse(global.privateFileMap[PluginName]["plugininfo"].toString());
var lang = JSON.parse(global.privateFileMap[PluginName]["lang"].toString())["lang"];
!global.data.lottery ? global.data.lottery = {} : "";

function getLang () {}
var onLoad = function (data) {
	check();
	if (global.getType(checkstatus) === "String") {
		console.log(checkstatus);
	}
	getLang = function (langVal, Lang) {
	    if (lang[Lang]) {
		    return String(lang[Lang][langVal]);
	    } else {
		    return String((lang[global.config.language] || {})[langVal]);
	    }
	}
}

// *buylottery*
var buyfunc = async function(type, data){
	!global.data.lottery[data.msgdata.threadID] ? global.data.lottery[data.msgdata.threadID] = {} : "";
    !global.data.lottery[data.msgdata.threadID][data.msgdata.senderID] ? global.data.lottery[data.msgdata.threadID][data.msgdata.senderID] = [] : "";
	if (data.msgdata.isGroup) {
		if(data.args.length <= 1){
			return {
			    handler: "internal",
		        data: getLang("NoLotteryNumber", data.resolvedLang)
		    }
		}
		if(isNaN(data.args[1].toString()) === false && (data.args[1].toString()).indexOf(".") == -1){
		    var number = parseInt(data.args[1], 10);
		    if(number >= parseInt(config["MinimumNumber"], 10) && number <= parseInt(config["MaximumNumber"], 10)){
    		    if(global.plugins.economy.validBalance(global.plugins.economy.getID(data.msgdata, type), parseInt(config["LotteryTicketPrize"], 10))){
	    		    if(global.data.lottery[data.msgdata.threadID][data.msgdata.senderID].length != 0){
	    	        	    var allowRun = false;
	    	        	var number1 = [];
	    		        for (var i in global.data.lottery[data.msgdata.threadID]) {
                            var number2 = global.data.lottery[data.msgdata.threadID][i];	
        	    		    number1 =  number1.concat(number2);
                        }
	    	    	    for (u = 0; u < number1.length; u++){
	    		    	    if(number == number1[u]){
	    			    	    return {
	    				  	        handler: "internal",
	    					        data: getLang("TakenlotteryNumber", data.resolvedLang).replace("{0}", number)
        					    }
        	    			}
	        	    		else {
	    	    	    		allowRun = true;
	    		    	    }
        			    }
	    		    }
	        		else{
	    				allowRun = true;
	    			}
                    if(allowRun){
		    	        global.plugins.economy.operator.subtract(global.plugins.economy.getID(data.msgdata, type), parseInt(config["LotteryTicketPrize"], 10), "lottery: buy ticket");
		    	    	global.data.lottery[data.msgdata.threadID][data.msgdata.senderID].push(number);
		    	        return {
		    	    	    handler: "internal",
		    		        data: getLang("BuyLotteryTicket", data.resolvedLang).replace("{0}", number)
    	    	    	}
		    	    }
	            }		
		        else {	
    	            return {
	        		    handler: "internal",
		                data: getLang("NotEnoughMoney", data.resolvedLang)
		            }
	            }
		    }
            else{
		    	return {
		    	    handler: "internal",
		    	    data: getLang("LotteryNumberCaution", data.resolvedLang).replace("{0}", parseInt(config["MinimumNumber"], 10)).replace("{1}", parseInt(config["MaximumNumber"], 10))
		        }
		    }
		}
		else{
		    return {
		    	handler: "internal",
		    	data: getLang("LotteryNumberCaution", data.resolvedLang).replace("{0}", parseInt(config["MinimumNumber"], 10)).replace("{1}", parseInt(config["MaximumNumber"], 10))
		    }
		}
	}
    else {
	    return {
		    handler: "internal",
		    data: getLang("GroupOnly", data.resolvedLang)
	    }
	}
}

// *lotteryshow*
var showfunc = async function(type, data){
	!global.data.lottery[data.msgdata.threadID] ? global.data.lottery[data.msgdata.threadID] = {} : "";
    !global.data.lottery[data.msgdata.threadID][data.msgdata.senderID] ? global.data.lottery[data.msgdata.threadID][data.msgdata.senderID] = [] : "";
	if (data.msgdata.isGroup) {
		var threadInfo = await data.facebookapi.getThreadInfo(data.msgdata.threadID);
        var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
        var isAdminGroup = adminIDs.indexOf(data.msgdata.senderID) != -1;
		if (isAdminGroup) {  
	        var prize = parseInt(config["WinnerPrize"], 10);
		    var prizenumber = random(parseInt(config["MinimumNumber"], 10),parseInt(config["MaximumNumber"], 10));
	        var allowRun = false; 
	        var participantIDs = threadInfo.participantIDs.map(x => x.toString());
	        for (var i = 0; i < participantIDs.length; i++) {
		        var number = global.data.lottery[data.msgdata.threadID][participantIDs[i]];
		        if (null != number){
		            if(global.data.lottery[data.msgdata.threadID][participantIDs[i]].indexOf(prizenumber) != -1){
        				var participant = participantIDs[i];
						allowRun = true;
			        }
				}
			}
	        if(allowRun){
				global.data.lottery[data.msgdata.threadID] = {};
				global.plugins.economy.operator.add("FB-"+participant, parseInt(config["WinnerPrize"], 10), "lottery: win prize");
				var info;
		        try {
                    info = await data.facebookapi.getUserInfo(participant);
                }
		        catch (err) {
                    return {
			            handler: "internal",
			            data: "err: "+ err
		            }
                }
				return {
					handler: "internal",
					data: getLang("WinLotterySeason", data.resolvedLang).replace("{0}", info[participant].name).replace("{1}", prizenumber).replace("{2}", parseInt(config["WinnerPrize"], 10))
				}
			}
			if (allowRun == 0){
				return {
					handler: "internal",
					data: getLang("NoneWinLotterySeason", data.resolvedLang).replace("{0}", prizenumber)
				}
			}
		}
		else {
			return {
				handler: "internal",
				data: getLang("AdminOnly", data.resolvedLang)
			}
		}
	}
	else {
		return {
			handler: "internal",
			data: getLang("GroupOnly", data.resolvedLang)
		}
	}
}

// *checklottery*
var checkfunc = function(type, data){
	!global.data.lottery[data.msgdata.threadID] ? global.data.lottery[data.msgdata.threadID] = {} : "";
    !(global.data.lottery[data.msgdata.threadID][data.msgdata.senderID]) ? global.data.lottery[data.msgdata.threadID][data.msgdata.senderID] = [] : "";
	if(global.data.lottery[data.msgdata.threadID] == {} || global.data.lottery[data.msgdata.threadID][data.msgdata.senderID].length == 0){
	    return {
		    handler: "internal",
	        data: getLang("NoLotteryTicket", data.resolvedLang)
	    }
	} else {
		return {
		    handler: "internal",
	        data: getLang("LotteryTicket", data.resolvedLang).replace("{0}", global.data.lottery[data.msgdata.threadID][data.msgdata.senderID].length).replace("{1}", global.data.lottery[data.msgdata.threadID][data.msgdata.senderID])
	    }
	}
} 

var random = function(min, max) { 
	return global.plugins.librandom.getRandomNumber(min, max, 0);
};

var checkstatus;
var check = function(data){
    function requireFromString(src, filename) {
        var Module = module.constructor;
        var m = new Module();
        m._compile(src, filename);
        return m.exports;
    }
	var path = global.nodemodule["path"];
	var func = requireFromString(global.privateFileMap[PluginName]["checker"].toString(),path.join(__dirname, "checker.js"));
	if(data == undefined || data.resolvedLang == undefined){
	    checkstatus = func.checkreturn(plugininfo, JSON.parse(global.privateFileMap[PluginName]["config"].toString()), JSON.parse(global.privateFileMap[PluginName]["lang"].toString()), global.config.language);
	}
	else {
		checkstatus = func.checkreturn(plugininfo, JSON.parse(global.privateFileMap[PluginName]["config"].toString()), JSON.parse(global.privateFileMap[PluginName]["lang"].toString()), data.resolvedLang);
	}
}

module.exports = {
	onLoad,
	buyfunc,
	showfunc,
	checkfunc
}
