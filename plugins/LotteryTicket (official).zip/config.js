{
	"config": {
		"LotteryTicketPrize": "100",
	    "WinnerPrize": "1000000000000",
	    "MinimumNumber": "0",
	    "MaximumNumber": "2"
	},
	"configdes": {
		"LotteryTicketPrize": [false, false, false, 0],
	    "WinnerPrize": [false, false, false, 0],
	    "MinimumNumber": [false, false, false, 0],
	    "MaximumNumber": [false, false, false, 0]
	}
}