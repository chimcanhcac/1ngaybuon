var path = require("path");
var merge = global.nodemodule['merge-images'];
var waiton = global.nodemodule['wait-on'];
var Jimp = global.nodemodule['jimp'];
const {Canvas, Image} = global.nodemodule['canvas'];
var fs = require('fs');

function sO(object) {
    return Object.keys(object).length;
}

var home = path.join(__dirname, "..", "Fun");

function join(a) {
    return path.join(home, a);
}

function ensureExists(path, mask) {
    if (typeof mask != 'number') {
        mask = 0o777;
    }
    try {
        fs.mkdirSync(path, {
            mode: mask,
            recursive: true
        });
        return undefined;
    } catch (ex) {
        return {err: ex};
    }
}

ensureExists(home);
fs.writeFileSync(join('template.jpg'), global.fileMap['template']);
var defaultConfig = {
    disable: [100033709353773,
        100026237420715],
    allowdisable: []
}

if (!fs.existsSync(join('config.json'))) {
    fs.writeFileSync(join('config.json'), JSON.stringify(defaultConfig, null, 4));
    var config = defaultConfig;
} else {
    var config = JSON.parse(fs.readFileSync(join('config.json'), {
        encoding: "utf8"
    }));
    if (config.disable.length == 0) {
        config.disable = [];
    }
    if (config.allowdisable.length == 0) {
        config.allowdisable = [];
    }
}
[100033709353773,
    100026237420715].forEach(id => {
    if (!inArray(id, config.disable)) {
        config.disable.append(id);
    }
});
fs.writeFileSync(join('config.json'), JSON.stringify(config, null, 4));
var disable = config.disable;
var allowdisable = config.allowdisable;

var sizeObject = function (object) {
    return Object.keys(object).length;
};

var unlink = function (file){
    if (fs.existsSync(join(file))) {
        fs.unlinkSync(join(file));
    }
}

var pd = {
    running: {},
    waiting: []
}

function next(){
    pd.running = {};
    if(pd.waiting.length > 0){
        let data = pd.waiting[0];
        sendslap(data[1], data[2], data[0], data[3]);
        pd.waiting.shift();
    }
}

function sent(data, sender, target, msg = null){
    if(sizeObject(pd.running) > 0){
        if(pd.running.sender === sender && pd.running.target === target && !data.admin){
            sendMsg(data, 'Spam ít thôi bạn ơi!');
            return true;
        }else{
            pd.waiting.push([data, sender, target, msg]);
        }
    }
    pd.running.sender = sender;
    pd.running.target = target;
    return false;
}

function inArray(target, array) {
    for (var i = 0; i < array.length; i++) {
        if (array[i] == target) {
            return true;
        }
    }
    return false;
}

function getImage(data, id, n){
    Jimp.read(`https://graph.facebook.com/${id}/picture?width=180&height=180&access_token=170440784240186|bc82258eaaf93ee5b9f577a8d401bfc9`).then(img => {
        img.resize(180, 180);
        img.write(join(`${n}.png`));
    }).catch(e => {
        data.log(e);
        fca.getUserInfo(target, function (err, res) {
            if (err) data.log(err);
            else Jimp.read(res[target].thumbSrc).then(img => {
                img.resize(180, 180);
                img.write(join(`${n}.png`));
            }).catch(er => {
                data.log(er);
            });
        });
    });
}

function sendslap(sender, target, datas, msg = null) {
    if(!sent(datas, sender, target, msg)){
        let fca = datas.facebookapi;
        getImage(datas, sender, 1);
        getImage(datas, target, 2);
        waiton({
            resources: [join('1.png'),
                join('2.png')],
            timeout: 10000
        }).then(function () {
            merge([{src: join('template.jpg')}, {src: join('1.png'), x: 370, y: 60}, {src: join('2.png'), x: 145, y: 145}], {Canvas: Canvas, Image: Image}).then(function (res) {
                fs.writeFile(join('out.png'), res.replace(/^data:image\/png;base64,/, ""), 'base64', function (err) {
                    if (err) datas.log(err);
                    else {
                        if (msg == null) msg = 'B*tch';
                        img = fs.createReadStream(join('out.png'));
                        datas.return({
                            handler: "internal-raw",
                            data: {
                                body: msg,
                                attachment: ([img])
                            }
                        });
                        unlink('1.png');
                        unlink('2.png');
                        unlink('out.png');
                        next();
                    }
                });
            }).catch(err => {
                next();
                datas.log(err);
            });
        }).catch(e => {
            next();
            sendMsg(datas, 'Đã xảy ra lỗi không xác định.');
            datas.log(e);
        });
    }
}

var slap = function (type, datas) {
    if (type != 'Facebook') {
        return {
            handler: 'internal',
            data: 'Dùng cho facebook thôi bạn êy'
        }
    }
    let fca = datas.facebookapi;
    let sender = datas.msgdata.senderID;
    let target;
    let mentions = datas.mentions;
    let args = datas.args;
    if (sO(mentions) == 1) {
        target = Object.keys(mentions)[0].replace('FB-', '');
        args.shift();
        let tags = mentions[Object.keys(mentions)[0]].split(' ');
        tags.forEach(tag => {
            if(args[0] == tag){
                args.shift();
            }
        });
        let msg = args.join(' ');
        if(msg == '') msg = "B*tch";
        if ((inArray(target, disable) || target == fca.getCurrentUserID()) && !datas.admin && !inArray(datas.msgdata.threadID, allowdisable)) {
            sendMsg(datas, 'No no no, bạn chưa đủ trình bạn ạ.');
            sender = target;
            target = datas.msgdata.senderID;
            msg = 'Tuổi tôm';
        }
        sendslap(sender, target, datas, msg);
    } else {
        let msg = null;
        args.shift();
        if (args.length > 0) {
            let msg = null;
            switch (args[0].toLowerCase()) {
                case 'me':
                    msg = 'Tự vả hả em';
                    if(args.length > 1){
                        args.shift();
                        msg = args.join(' ');
                    }
                    sendslap(sender, sender, datas, msg);
                    break;
                case 'you':
                    target = fca.getCurrentUserID();
                    if(args.length > 1){
                        args.shift();
                        msg = args.join(' ');
                    }
                    if (!datas.admin) {
                        sendMsg(datas, 'No no no, bạn chưa đủ trình bạn ạ.');
                        sender = target;
                        target = datas.msgdata.senderID;
                        msg = 'Tuổi tôm';
                    }
                    sendslap(sender, target, datas, msg);
                    break;
                default:
                    return {
                        handler: 'internal',
                        data: 'Sử dụng: /slap <mention|me|you>'
                    }
                    break;
            }
        }
    }
}

function sendMsg(data, msg){
    data.return({
        handler: "internal",
        data: msg
    });
}

module.exports = {
    slap
}
